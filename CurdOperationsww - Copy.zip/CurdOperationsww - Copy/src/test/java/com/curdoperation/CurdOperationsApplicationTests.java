package com.curdoperation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurdOperationsApplicationTests {

	@Test //Debug main use
	void contextLoads() {
	}

}
